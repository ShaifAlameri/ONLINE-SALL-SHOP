// Example JavaScript code for form validation
document.querySelector('form').addEventListener('submit', function(event) {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
  
    if (name === '' || email === '') {
      event.preventDefault();
      alert('Please fill in all fields.');
    }
  });